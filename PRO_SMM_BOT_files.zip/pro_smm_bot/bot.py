import asyncio
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from uuid import uuid4
from aiogram import Bot, Dispatcher, F
from aiogram.filters import Command, CommandStart
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.fsm.storage.redis import RedisStorage
from redis.asyncio import Redis
from sqlalchemy import select, func
from config import settings
from database import init_db, engine, SessionLocal
from models import User, Category, Service, Order, Payment, Transaction, AuditLog, SupportTicket
from keyboards import main_menu, admin_menu

def admin(uid): return uid in settings.admins

async def main():
    if not settings.bot_token or settings.bot_token == "PASTE_NEW_TOKEN_HERE":
        raise RuntimeError("BOT_TOKEN ni .env faylida sozlang.")
    await init_db()
    redis = Redis.from_url(settings.redis_url)
    bot = Bot(settings.bot_token, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
    dp = Dispatcher(storage=RedisStorage(redis=redis))

    @dp.message(CommandStart())
    async def start(m):
        async with SessionLocal() as s:
            u = await s.scalar(select(User).where(User.telegram_id == m.from_user.id))
            if not u:
                s.add(User(telegram_id=m.from_user.id, full_name=m.from_user.full_name[:200], username=m.from_user.username))
                await s.commit()
            elif u.is_blocked:
                await m.answer("Akkauntingiz bloklangan.")
                return
        await m.answer("Assalomu alaykum! PRO SMM BOT'ga xush kelibsiz.", reply_markup=main_menu())

    @dp.message(F.text == "🛍 Xizmatlar katalogi")
    async def catalog(m):
        async with SessionLocal() as s:
            cats = (await s.scalars(select(Category).where(Category.is_active.is_(True)).order_by(Category.id))).all()
            services = (await s.scalars(select(Service).where(Service.is_active.is_(True)).order_by(Service.id))).all()
        if not cats:
            await m.answer("Katalog hali bo‘sh. Administrator xizmatlar qo‘shishi kerak.")
            return
        lines = ["🛍 <b>Xizmatlar katalogi</b>"]
        for c in cats:
            lines.append(f"\n<b>{c.id}. {c.name}</b>")
            for v in services:
                if v.category_id == c.id:
                    lines.append(f"#{v.id} {v.name} — {v.price_per_1000} so‘m/1000; miqdor {v.min_quantity}-{v.max_quantity}")
        lines.append("\nBuyurtma: /order XIZMAT_ID HAVOLA MIQDOR")
        await m.answer("\n".join(lines))

    @dp.message(Command("order"))
    async def order(m):
        parts = (m.text or "").split(maxsplit=3)
        if len(parts) != 4:
            await m.answer("Format: /order XIZMAT_ID https://havola 100")
            return
        try:
            sid, qty = int(parts[1]), int(parts[3])
            url = parts[2]
            if qty <= 0 or not url.startswith(("https://", "http://")) or len(url) > 1500: raise ValueError()
        except ValueError:
            await m.answer("Xizmat ID, havola yoki miqdor noto‘g‘ri.")
            return
        async with SessionLocal() as s:
            try:
                async with s.begin():
                    u = await s.scalar(select(User).where(User.telegram_id == m.from_user.id).with_for_update())
                    v = await s.scalar(select(Service).where(Service.id == sid, Service.is_active.is_(True)))
                    if not u or u.is_blocked: raise ValueError("Foydalanuvchi topilmadi yoki bloklangan.")
                    if not v: raise ValueError("Xizmat topilmadi.")
                    if not v.min_quantity <= qty <= v.max_quantity: raise ValueError(f"Miqdor {v.min_quantity}-{v.max_quantity} oralig‘ida bo‘lsin.")
                    price = (Decimal(v.price_per_1000) * qty / Decimal(1000)).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
                    if Decimal(u.balance) < price: raise ValueError(f"Balans yetarli emas. Narx: {price} so‘m.")
                    oid = uuid4().hex[:12].upper()
                    u.balance = Decimal(u.balance) - price
                    s.add(Transaction(user_id=u.id, amount=-price, kind="order_debit", reference=oid, idempotency_key=f"order:{oid}", note="Buyurtma uchun yechim"))
                    s.add(Order(public_id=oid, user_id=u.id, service_id=v.id, target_url=url, quantity=qty, total_price=price, status="pending"))
            except ValueError as e:
                await m.answer(str(e)); return
        await m.answer(f"✅ Buyurtma yaratildi: <code>#{oid}</code>\nNarx: {price} so‘m\nHolat: Kutilmoqda. Administrator tekshiradi.")

    @dp.message(F.text == "💰 Mening balansim")
    async def balance(m):
        async with SessionLocal() as s:
            u = await s.scalar(select(User).where(User.telegram_id == m.from_user.id))
        await m.answer(f"💰 Balans: {u.balance if u else 0} so‘m")

    @dp.message(F.text == "➕ Hisobni to‘ldirish")
    async def topup_help(m):
        await m.answer("Hisobni to‘ldirish so‘rovi: /topup 25000. To‘lov chek asosida avtomatik tasdiqlanmaydi; administrator tekshiradi.")

    @dp.message(Command("topup"))
    async def topup(m):
        p=(m.text or "").split()
        try:
            amount=Decimal(p[1])
            if len(p)!=2 or amount < 1000 or amount > 10000000 or amount != amount.quantize(Decimal("1")): raise ValueError()
        except Exception:
            await m.answer("Format: /topup 25000 (1 000–10 000 000 so‘m)"); return
        async with SessionLocal() as s:
            u=await s.scalar(select(User).where(User.telegram_id==m.from_user.id))
            if not u: await m.answer("Avval /start bosing."); return
            pid=uuid4().hex[:12].upper()
            s.add(Payment(public_id=pid,user_id=u.id,amount=amount,method="manual_card",status="pending"))
            await s.commit()
        card = f"\nKarta: <code>{settings.payment_card_number}</code>\nQabul qiluvchi: {settings.payment_card_holder}" if settings.payment_card_number else "\nKarta rekvizitlari administrator tomonidan sozlanmagan."
        await m.answer(f"To‘lov so‘rovi #{pid}\nSumma: {amount} so‘m{card}\nTo‘lovdan so‘ng chekni administratorga yuboring. Chek avtomatik tasdiqlanmaydi.")
        for aid in settings.admins:
            try: await bot.send_message(aid, f"Yangi to‘lov: #{pid}\nFoydalanuvchi Telegram ID: {m.from_user.id}\nSumma: {amount} so‘m\nTekshirib: /approve_payment {pid}")
            except Exception: pass

    @dp.message(Command("approve_payment"))
    async def approve(m):
        if not admin(m.from_user.id): return
        p=(m.text or "").split()
        if len(p)!=2: await m.answer("Format: /approve_payment PAYMENT_ID"); return
        async with SessionLocal() as s:
            try:
                async with s.begin():
                    pay=await s.scalar(select(Payment).where(Payment.public_id==p[1]).with_for_update())
                    if not pay or pay.status!="pending": raise ValueError("To‘lov topilmadi yoki avval ko‘rib chiqilgan.")
                    u=await s.scalar(select(User).where(User.id==pay.user_id).with_for_update())
                    tx=await s.scalar(select(Transaction).where(Transaction.idempotency_key==f"payment:{pay.public_id}"))
                    if tx: raise ValueError("To‘lov avval hisobga olingan.")
                    u.balance=Decimal(u.balance)+Decimal(pay.amount)
                    s.add(Transaction(user_id=u.id,amount=pay.amount,kind="manual_payment",reference=pay.public_id,idempotency_key=f"payment:{pay.public_id}",note="Admin tasdiqladi"))
                    pay.status="successful"
                    s.add(AuditLog(admin_telegram_id=m.from_user.id,action="payment_approved",target=pay.public_id))
                    tg=u.telegram_id; amount=pay.amount
            except ValueError as e: await m.answer(str(e)); return
        try: await bot.send_message(tg,f"✅ {amount} so‘m to‘lov tasdiqlandi.")
        except Exception: pass
        await m.answer("To‘lov tasdiqlandi.")

    @dp.message(Command("reject_payment"))
    async def reject(m):
        if not admin(m.from_user.id): return
        p=(m.text or "").split()
        if len(p)!=2: await m.answer("Format: /reject_payment PAYMENT_ID"); return
        async with SessionLocal() as s:
            pay=await s.scalar(select(Payment).where(Payment.public_id==p[1]).with_for_update())
            if not pay or pay.status!="pending": await m.answer("To‘lov topilmadi yoki ko‘rib chiqilgan."); return
            pay.status="rejected"; s.add(AuditLog(admin_telegram_id=m.from_user.id,action="payment_rejected",target=pay.public_id)); await s.commit()
        await m.answer("To‘lov rad etildi.")

    @dp.message(F.text == "📦 Buyurtmalarim")
    async def myorders(m):
        async with SessionLocal() as s:
            u=await s.scalar(select(User).where(User.telegram_id==m.from_user.id))
            os=(await s.scalars(select(Order).where(Order.user_id==u.id).order_by(Order.id.desc()).limit(10))).all() if u else []
        if not os: await m.answer("Buyurtmalar topilmadi."); return
        await m.answer("\n".join(f"#{o.public_id} — {o.total_price} so‘m — {o.status}" for o in os))

    @dp.message(F.text == "📜 To‘lovlar tarixi")
    async def payments(m):
        async with SessionLocal() as s:
            u=await s.scalar(select(User).where(User.telegram_id==m.from_user.id))
            ps=(await s.scalars(select(Payment).where(Payment.user_id==u.id).order_by(Payment.id.desc()).limit(10))).all() if u else []
        await m.answer("\n".join(f"#{p.public_id} — {p.amount} so‘m — {p.status}" for p in ps) or "To‘lovlar tarixi bo‘sh.")

    @dp.message(F.text == "👤 Profilim")
    async def profile(m):
        async with SessionLocal() as s:
            u=await s.scalar(select(User).where(User.telegram_id==m.from_user.id))
            if not u: await m.answer("Avval /start bosing."); return
            n=await s.scalar(select(func.count(Order.id)).where(Order.user_id==u.id))
        await m.answer(f"👤 Profil\nTelegram ID: {u.telegram_id}\nIsm: {u.full_name}\nBalans: {u.balance} so‘m\nBuyurtmalar: {n or 0}")

    @dp.message(F.text == "🎁 Promokodlar")
    async def promos(m): await m.answer("Promokod funksiyasi keyingi versiyada ulanadi.")

    @dp.message(F.text == "📖 Foydalanish qoidalari")
    async def rules(m): await m.answer("Faqat qonuniy, platforma qoidalariga mos xizmatlardan foydalaning. Spam, aldov va soxta faollik taqiqlanadi. To‘lovlar tekshiruvdan so‘ng tasdiqlanadi.")

    @dp.message(F.text == "💬 Yordam xizmati")
    async def helpdesk(m):
        await m.answer("Murojaat yuborish: /support MUROJAAT_MATNI")

    @dp.message(Command("support"))
    async def support(m):
        msg=(m.text or "").partition(" ")[2].strip()
        if not msg or len(msg)>3000: await m.answer("Format: /support Murojaatingiz matni"); return
        tid=uuid4().hex[:10].upper()
        async with SessionLocal() as s:
            u=await s.scalar(select(User).where(User.telegram_id==m.from_user.id))
            if not u: await m.answer("Avval /start bosing."); return
            s.add(SupportTicket(public_id=tid,user_id=u.id,message=msg)); await s.commit()
        for aid in settings.admins:
            try: await bot.send_message(aid,f"Yordam murojaati #{tid}\nTelegram ID: {m.from_user.id}\n{msg}\nJavob: /reply_ticket {tid} javob matni")
            except Exception: pass
        await m.answer(f"Murojaat qabul qilindi: #{tid}")

    @dp.message(Command("reply_ticket"))
    async def reply_ticket(m):
        if not admin(m.from_user.id): return
        p=(m.text or "").split(maxsplit=2)
        if len(p)<3: await m.answer("Format: /reply_ticket TICKET_ID Javob"); return
        async with SessionLocal() as s:
            t=await s.scalar(select(SupportTicket).where(SupportTicket.public_id==p[1]))
            if not t: await m.answer("Murojaat topilmadi."); return
            t.admin_reply=p[2]; t.status="answered"
            tg=await s.scalar(select(User.telegram_id).where(User.id==t.user_id)); await s.commit()
        await bot.send_message(tg,f"Javob #{p[1]}: {p[2]}"); await m.answer("Javob yuborildi.")

    @dp.message(Command("admin"))
    async def admin_panel(m):
        if admin(m.from_user.id): await m.answer("Administrator paneli. Buyruqlar uchun README.md ni ko‘ring.", reply_markup=admin_menu())

    @dp.message(Command("add_category"))
    async def add_category(m):
        if not admin(m.from_user.id): return
        name=(m.text or "").partition(" ")[2].strip()
        if not name or len(name)>120: await m.answer("Format: /add_category Kategoriya nomi"); return
        async with SessionLocal() as s:
            if await s.scalar(select(Category).where(Category.name==name)): await m.answer("Kategoriya mavjud."); return
            s.add(Category(name=name)); s.add(AuditLog(admin_telegram_id=m.from_user.id,action="category_created",target=name)); await s.commit()
        await m.answer("Kategoriya qo‘shildi: "+name)

    @dp.message(Command("add_service"))
    async def add_service(m):
        if not admin(m.from_user.id): return
        parts=[x.strip() for x in (m.text or "").partition(" ")[2].split("|")]
        if len(parts)!=6: await m.answer("Format: /add_service CATEGORY_ID | Nomi | Narx/1000 | min | max | Tavsif"); return
        try:
            cid=int(parts[0]); name=parts[1]; price=Decimal(parts[2]); mn=int(parts[3]); mx=int(parts[4]); desc=parts[5]
            if price<=0 or mn<1 or mx<mn: raise ValueError()
        except Exception: await m.answer("Ma’lumot noto‘g‘ri."); return
        async with SessionLocal() as s:
            if not await s.get(Category,cid): await m.answer("Kategoriya topilmadi."); return
            v=Service(category_id=cid,name=name,price_per_1000=price,min_quantity=mn,max_quantity=mx,description=desc)
            s.add(v); s.add(AuditLog(admin_telegram_id=m.from_user.id,action="service_created",target=name)); await s.commit()
        await m.answer(f"Xizmat qo‘shildi: ID {v.id}")

    @dp.message(Command("set_order"))
    async def set_order(m):
        if not admin(m.from_user.id): return
        p=(m.text or "").split()
        if len(p)!=3 or p[2] not in {"pending","processing","completed","cancelled","partial"}:
            await m.answer("Format: /set_order ORDER_ID processing|completed|cancelled|partial"); return
        async with SessionLocal() as s:
            o=await s.scalar(select(Order).where(Order.public_id==p[1]))
            if not o: await m.answer("Buyurtma topilmadi."); return
            o.status=p[2]; s.add(AuditLog(admin_telegram_id=m.from_user.id,action="order_status_changed",target=o.public_id,details=p[2])); await s.commit()
        await m.answer("Buyurtma holati yangilandi.")

    @dp.message(F.text == "📋 Kutilayotgan to‘lovlar")
    async def pending(m):
        if not admin(m.from_user.id): return
        async with SessionLocal() as s: ps=(await s.scalars(select(Payment).where(Payment.status=="pending").limit(30))).all()
        await m.answer("\n".join(f"#{p.public_id}: {p.amount} so‘m — /approve_payment {p.public_id}" for p in ps) or "Kutilayotgan to‘lov yo‘q.")

    @dp.message(F.text == "📦 Buyurtmalarni boshqarish")
    async def admin_orders(m):
        if not admin(m.from_user.id): return
        async with SessionLocal() as s: os=(await s.scalars(select(Order).order_by(Order.id.desc()).limit(20))).all()
        await m.answer("\n".join(f"#{o.public_id} — {o.total_price} — {o.status} — /set_order {o.public_id} processing" for o in os) or "Buyurtmalar yo‘q.")

    @dp.message(F.text == "📊 Statistika")
    async def stats(m):
        if not admin(m.from_user.id): return
        async with SessionLocal() as s:
            us=await s.scalar(select(func.count(User.id))); os=await s.scalar(select(func.count(Order.id)))
            done=await s.scalar(select(func.count(Order.id)).where(Order.status=="completed"))
        await m.answer(f"Foydalanuvchilar: {us}\nBuyurtmalar: {os}\nBajarilgan: {done}")

    @dp.message(F.text == "⬅️ Asosiy menyu")
    async def back(m): await m.answer("Asosiy menyu", reply_markup=main_menu())

    try:
        await bot.delete_webhook(drop_pending_updates=False)
        await dp.start_polling(bot)
    finally:
        await bot.session.close()
        await redis.aclose()
        await engine.dispose()

if __name__ == "__main__":
    asyncio.run(main())
