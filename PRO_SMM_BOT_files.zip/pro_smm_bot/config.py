from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    bot_token: str
    admin_ids: str = ""
    database_url: str = "postgresql+asyncpg://postgres:postgres@localhost:5432/pro_smm_bot"
    redis_url: str = "redis://localhost:6379/0"
    payment_card_holder: str = ""
    payment_card_number: str = ""
    support_username: str = ""
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    @property
    def admins(self):
        return [int(x.strip()) for x in self.admin_ids.split(",") if x.strip().isdigit()]

settings = Settings()
