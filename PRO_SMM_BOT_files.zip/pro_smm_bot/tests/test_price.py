from decimal import Decimal, ROUND_HALF_UP

def calc(price, qty):
    if qty <= 0: raise ValueError
    return (Decimal(price) * qty / Decimal(1000)).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)

def test_price():
    assert calc("15000", 1000) == Decimal("15000.00")
    assert calc("15000", 100) == Decimal("1500.00")

def test_zero():
    try: calc("1000", 0)
    except ValueError: return
    assert False
