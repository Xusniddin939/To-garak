from aiogram.types import ReplyKeyboardMarkup, KeyboardButton

def main_menu():
    rows = [
        [KeyboardButton(text="🛍 Xizmatlar katalogi"), KeyboardButton(text="💰 Mening balansim")],
        [KeyboardButton(text="➕ Hisobni to‘ldirish"), KeyboardButton(text="📦 Buyurtmalarim")],
        [KeyboardButton(text="📜 To‘lovlar tarixi"), KeyboardButton(text="🎁 Promokodlar")],
        [KeyboardButton(text="👤 Profilim"), KeyboardButton(text="💬 Yordam xizmati")],
        [KeyboardButton(text="📖 Foydalanish qoidalari")]
    ]
    return ReplyKeyboardMarkup(keyboard=rows, resize_keyboard=True)

def admin_menu():
    return ReplyKeyboardMarkup(keyboard=[
        [KeyboardButton(text="➕ Kategoriya qo‘shish"), KeyboardButton(text="➕ Xizmat qo‘shish")],
        [KeyboardButton(text="📋 Kutilayotgan to‘lovlar"), KeyboardButton(text="📦 Buyurtmalarni boshqarish")],
        [KeyboardButton(text="📊 Statistika"), KeyboardButton(text="⬅️ Asosiy menyu")]
    ], resize_keyboard=True)
