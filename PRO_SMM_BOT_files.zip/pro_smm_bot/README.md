# PRO SMM BOT — birinchi ishga tushiriladigan versiya

## Muhim
Bu boshlang‘ich versiya: menyu, PostgreSQL, xizmatlar, buyurtma, balans, qo‘lda tekshiriladigan to‘lov so‘rovi, admin buyruqlari va yordam murojaatlari mavjud. Payme/Click avtomatik API integratsiyasi bu ZIP ichida hali yo‘q. To‘lov chek rasmi bilan avtomatik tasdiqlanmaydi. Soxta faollik/spam xizmatlarini qo‘shmang.

## 1. Token va admin ID
Agar oldingi token ochiq yuborilgan bo‘lsa, BotFather'da bekor qilib yangi token oling. Tokenni hech kimga yubormang. `.env.example` faylini `.env` qilib nusxalang. `BOT_TOKEN` va `ADMIN_IDS` ni to‘ldiring. Telegram ID raqamingizni `ADMIN_IDS` ga yozing.

## 2. Docker orqali
VPS yoki Docker ishlaydigan muhitda:
1. `POSTGRES_PASSWORD` uchun kuchli parol belgilang.
2. `docker compose up -d --build`
3. Log: `docker compose logs -f bot`

`.env` faylini hech qachon ommaviy GitHub reposiga yuklamang.

## 3. Admin buyruqlari
- `/admin`
- `/add_category Telegram xizmatlari`
- `/add_service 1 | Kontent tahlili | 15000 | 1 | 100 | Kontent bo‘yicha maslahat`
- `/approve_payment PAYMENT_ID` — faqat haqiqiy tushumni tekshirgandan keyin
- `/reject_payment PAYMENT_ID`
- `/set_order ORDER_ID processing`
- `/reply_ticket TICKET_ID Javob matni`

## 4. Foydalanuvchi buyruqlari
- `/start`
- `/topup 25000`
- `/order SERVICE_ID https://example.com/page 100`
- `/support Murojaat matni`

## 5. To‘lov provayderi
Payme yoki Click integratsiyasidan oldin rasmiy merchant hujjatlari, webhook imzosi, idempotency va refund tartibi tekshirilishi kerak. Haqiqiy provayder sozlanmaguncha avtomatik to‘lov deb e’lon qilmang.

## 6. Cheklovlar
- Hozircha schema ilk ishga tushishda SQLAlchemy `create_all` orqali yaratiladi; ishlab chiqarishda Alembic migratsiyalarini qo‘shish kerak.
- Redis FSM saqlash uchun ishlatiladi; to‘liq rate limiting, monitoring, backup/restore mashqi va provider webhook serveri keyingi bosqichda qo‘shilishi lozim.
- Serverga joylashtirishdan oldin staging testlarini bajaring.
